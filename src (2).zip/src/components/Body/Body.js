import React from "react"
import LNavbar from "./Link-Navbar/Link-Navbar.js"
import Footer from "./Footer/Footer.js"
import "./Body.css"
import Graph from "./Graph/Graph.js"
import CDetails from "./Company-Details/Company-Details.jsx"
import VSIDEBAR from "../Vertical-Sidebar/Vertical-Sidebar.js"
export default function Body(){
    return(
    <>
    <div className="body-align">
    <div className="body-left">
    <VSIDEBAR/>
    </div>
    <div className="body-space">
        <LNavbar/>
        <Graph/>
        <CDetails/>
        <Footer/>
    </div> 
    </div>
    </>)
}