import React, { useState } from 'react';
import { useEffect } from 'react';
import { Route, Routes, useNavigate } from 'react-router-dom';
import * as FaIcons from 'react-icons/fa';
import * as AiIcons from 'react-icons/ai';
import * as IoIcons from 'react-icons/io';
import { Link } from 'react-router-dom';
import './Vertical-Sidebar.css';
import { IconContext } from 'react-icons';
import MenuIcon from '../../assets/menu.svg'
import Homepage from '../../pages/Homepage';

const SidebarData = [
  {
    title: 'HOME',
    path: '../pages/Homepage.jsx',
    icon: <AiIcons.AiFillHome />,
    cName: 'nav-text'
  },
  // {
  //   title: 'News',
  //   path: '../pages/Reliance.jsx',
  //   icon: <IoIcons.IoIosPaper />,
  //   cName: 'nav-text'
  // },
  {
    title: 'RIL',
    path: '/products',
    icon: <AiIcons.AiFillTrademarkCircle />,
    cName: 'nav-text'
  },
  {
    title: 'TCS',
    path: '/team',
    icon: <AiIcons.AiFillTrademarkCircle />,
    cName: 'nav-text'
  },
  {
    title: 'HDFC',
    path: '/messages',
    icon: <AiIcons.AiFillTrademarkCircle />,
    cName: 'nav-text'
  },
  {
    title: 'SBI',
    path: '/support',
    icon: <AiIcons.AiFillTrademarkCircle />,
    cName: 'nav-text'
  }
];

// function Redirect(name){
//   const navigate = useNavigate();
//   useEffect(() => {
//       setTimeout(() => {
//           navigate('../Homepage', { replace: true });
//       }, 10);
//     }, []);
  
//     return <div>Redirecting...</div>;
// }
export default function VSIDEBAR() {
  const [isExpanded, setIsExpanded]=useState(false);

  const toggleExpanded=()=> setIsExpanded((prevIsExpanded)=>!prevIsExpanded);


  return (
    <>
    <div className='body-container'>
      <IconContext.Provider value={{ color: '#fff' }}>
        {/* <div className='navbar'>
          <Link to='#' className='menu-bars'>
            <FaIcons.FaBars onClick={showSidebar} />
          </Link>
        </div> */}
        <nav className='nav-menu'>
          <ul className='nav-menu-items'>
          {/* <ul className='nav-menu-items' onClick={showSidebar}> */}
            <li className='navbar-toggle'>
              {/* <Link to='#' className='menu-bars'>
                <AiIcons.AiOutlineClose />
              </Link> */}
            </li>
            {SidebarData.map((item, index) => {
              return (
                <li key={index} className={item.cName}>
                  <Link to={item.path} >
                    {item.icon}
                    <span>{item.title}</span>
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>
      </IconContext.Provider>
      <button className="hamburger hamburger-prop" onClick={toggleExpanded}>
                <img src={MenuIcon}/>
      </button>
      <div>
                {    isExpanded &&
                   ( <div className="menu-overlay">
                    <div className="menu-links">
                    {SidebarData.map((item, index) => {
              return (
               
                  <Link to={item.path}>
                    <span>{item.title}</span>
                  </Link>
              );
            })}
                </div>
                </div>
                )}
      </div>
      </div>
    </>
  );
}
