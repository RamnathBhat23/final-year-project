import React from 'react'

export default function Footer() {
  return (
    <div className='footer-container'>
        <div className='footer-copyright'>
            <p>Developed by Team StockIntel</p>
            </div> 
        </div>
  );
}

