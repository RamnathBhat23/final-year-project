import React from 'react';
import './Header.css';
// import logoUrl from '../../assets/logo.svg';
export default function Header(){
  return(
    <>
      <div className="header">
          <h1>Stock Intel</h1>
      </div>
    </>)
}