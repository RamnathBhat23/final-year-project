import Header from '../components/Header/Header.js';
import VSIDEBAR from '../components/Vertical-Sidebar/Vertical-Sidebar.js';
import DASHBODY from '../components/DashboardBody/DashboardBody.js';

export default function Dashboard(){
    return (
        <>
        <Header/>
        <VSIDEBAR/>
        <DASHBODY/>
        </>
    )
}