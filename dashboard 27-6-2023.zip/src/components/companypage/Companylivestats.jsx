import React from 'react'
import styled from "styled-components";
import { applyCardStyles } from "./ReusableStyles";
import OPEN from '../../assets/OPEN.png'
import LOW from '../../assets/LOW.png'
import HIGH from '../../assets/HIGH.png'
import VOLUME from '../../assets/VOLUME.png'
// Reusable component for displaying data
const data = [
  {
    type: 'Open',
    value: 2345,
    logo: OPEN
  },
  {
    type: 'Volume',
    value: 3456,
    logo: VOLUME
  },
  {
    type: 'High',
    value: 4567,
    logo: HIGH
  },
  {
    type: 'Low',
    value: 5678,
    logo: LOW
  }
];

const DataDisplay = ({ logoSrc, dataTitle, dataValue }) => {
  return (
    <>
    <Section>

    <div className='icon'>
      <img src={logoSrc} alt={`${dataTitle} Logo`} />
    </div>
    <div className='textcontent'>
      <h2>{`${dataTitle}  `}</h2><h3>{`₹${dataValue}`}</h3>
    </div>
    </Section>
    </>
  );
};
function Companylivestats() {
  return (
    <>
    <div>
      {data.map((item) => (
        <DataDisplay
          key={item.type}
          logoSrc={item.logo}
          dataTitle={item.type}
          dataValue={item.value}
        />
      ))}
    </div>
      {/* <div>
      <Section>
        <div className='icon'>
        <img src={OPEN} alt="OPEN Logo" />
        </div>
        <div className='textcontent'>
          <h1>Open : ₹2345 </h1>
        </div>
      </Section>

      </div> */}
    </>
  )
}

const Section = styled.section`
  ${applyCardStyles}
  color:white;
  width:15%;
  margin:10px;
  margin-left:2rem;
  justify-content: center;
  -webkit-box-orient: vertical;
  display: -webkit-inline-box;
  flex-direction: row;
  justify-content: space-between;
  align-items:center;
  .title-container {
    margin-bottom: 1rem;
    .title {
      display: flex;
      justify-content: space-between;
      svg {
        color: var(--primary-color);
        font-size: 1.3rem;
        cursor: pointer;
      }
    }
  }
  @media screen and (min-width: 280px) and (max-width: 1080px) {
    flex-direction: column;
    align-items: center;
    margin: 1rem;
    margin-bottom: 0;
    .timeline {
      gap: 1rem;
    }
  }
`  ;
export default Companylivestats