import React from 'react';
import Reliance from "../../assets/icons/RELIANCE.svg"
import TCS from "../../assets/icons/TCS.svg"
import HDFC from "../../assets/icons/HDFC.svg"
import SBI from "../../assets/icons/SBI.svg"

export default function FeatureOne(){
    const companies=[
        {
          id:"RIL",
          src:Reliance,
          title:"Reliance Industries", 
          desc:"Mid cap",
          price:2200
        },
        {
          id:"TCS",
          src:TCS,
          title:"Tata Consultancy Services", 
          desc:"Mid cap",
          price:3200
        },
        {
          id:"HDFC",
          src:HDFC,
          title:"HDFC Bank", 
          desc:"Mid cap",
          price:1500
        },
        {
          id:"SBI",
          src:SBI,
          title:"State Bank of India", 
          desc:"Mid cap",
          price:550
        }
      ]
    // const tokens=["RIL","HDFC","TCS","SBI"];
    return (
    <div className='feature-container'>
        <div className='swap-token-container'>
            <div className='tokens-container'>
                { companies.map((company,index)=>{
                    return(
                        <>
                            <div className='token-container'>
                              {
                                 <div className='token-info'>
                                    <img className='token-logo' src={company.src}/>
                                    <div className='token-title-container'>
                                         <span className='token-title'>
                                        {company.title}
             
                                        </span>
                                    <span className='token-title-long'>
                                        {/* {company.desc} */}
                                    </span>
                                </div>
                            </div>
                             }
                          {/* <div className='token-amount-container'> */}
                         {/* <div className='btn-container'>
                         </div> */}
                            <button className='primary'>Check Out!</button>
                             {/* <div className='token-amount'>Stock Price  {company.price}</div> */}
                                {/* </div> */}
                             </div> 
                        </>
                )
                })}
            </div>
            {/* <div className='btn-container'>
                <button className='primary'>Check Out!</button>
            </div> */}
        </div>
        <br />
        <div className='feature-description'>
            <div className='feature-description-title'>
                <h1>
                    <span className='highlighted'>StockIntel</span> 
                    {/* Bluechip stocks */}
                </h1>
                <br />
                    Predicting Stock Prices
            </div>
            {/* <br /> */}
                <p className='feature-description-paragraph'>
                    we&#39;have created stock intel to help you help you predict stock price and make buying descions easily with research and market and market analysis which will improve your chances of making profits.
                </p>
                <div className='btn-container'>
                    {/* <button className="secondary">
                        <span>Start your Journey</span>
                    </button> */}
                </div>
        </div>
    </div>
  )
}
