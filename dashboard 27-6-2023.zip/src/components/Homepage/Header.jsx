import React,{useState} from "react";
import { useEffect } from 'react';
import { Route, Routes, useNavigate } from 'react-router-dom';
import MenuIcon from "../../assets/icons/hamburger.svg";

// function Redirect(name){
//     const navigate = useNavigate();
//     useEffect(() => {
//         setTimeout(() => {
//             navigate('../Reliance', { replace: true });
//         }, 10);
//       }, []);
    
//       return <div>Redirecting...</div>;
// }
function Header(){
    const [isExpanded, setIsExpanded]=useState(false);

    const toggleExpanded=()=> setIsExpanded((prevIsExpanded)=>!prevIsExpanded);



    return(
        <>
        <div className='header-container'>
            {/* <div className="logo">STOCK INTEL</div> */}
            <div className="menu">
                <div className="menu-links">
                    <a href="/">Home</a>
                    <a href="/">About us</a>
                    <a href="/" >Reliance</a>
                    {/* <a href="/" onClick={Redirect("RIL") }>Reliance</a> */}
                    <a href="/" >TCS</a>
                    <a href="/" >HDFC BANK</a>
                    <a href="/" >SBI BANK</a>
                </div>
            </div>
            {/* <div className="wallet-btn">
                <button className="primary">Enter APP</button>
            </div> */}
            <button className="hamburger hamburger-prop" onClick={toggleExpanded}>
                <img src={MenuIcon}/>
            </button>
        </div>
        {
                    isExpanded &&
                   ( <div className="menu-overlay">
                          <div className="menu-links">
                    <a href="/">About</a>
                    <a href="/CompanyHome">Reliance</a>
                    <a href="/">HDFC</a>
                    <a href="/">SBI</a>
                    <a href="/">TCS</a>
                </div>
                    </div>
                )}
        </>
    );
}

export default Header;
