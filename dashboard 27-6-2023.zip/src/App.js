// import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Reliancecompany from "pages/Reliancecompany";
// import Dashboard from "pages/Dashboard";
import Homepage from "pages/Homepage";
import Companylivestats from "components/companypage/Companylivestats";
export default function App() {
  
  return (
    <>
      {/* <Homepage/> */}
      <Reliancecompany/>
    </>
  );
}