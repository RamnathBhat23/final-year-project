import Header from '../components/Homepage/Header/Header.js';
import VSIDEBAR from '../components/Homepage/Vertical-Sidebar/Vertical-Sidebar.js';
import DASHBODY from '../components/Homepage/DashboardBody/DashboardBody.js';

export default function Dashboard(){
    return (
        <>
        <Header/>
        <VSIDEBAR/>
        <DASHBODY/>
        </>
    )
}