import React from "react";
// import search from '../../assets/icons/search.png';
// import { ReactComponent as TelegramIcon } from "../assets/icons/telegram.svg";
import hero from "../../assets/icons/stock.webp";

export default function HeroSection(){
    return(<>
    <div className="hero-section-container">
        <div className="hero-info-wrapper">
            <div className="hero-info-text">

            <h1>
               <span className="highlighted">Predicting</span>The Unpredictables
            </h1>
            <p className="hero-info-description">
                This is the one stop solution for all Stock amrket users for all Stock market users to get accurate insights o invest wisely
            </p>
                <div className="social-links-container">
                    <div className="social-links">
                        <a href="/">
                            {/* <TelegramIcon/> */}
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div className="hero-image-container">
            <div>
                <img className="hero-img" src={hero} alt="stockmarket"/>
            </div>
        </div>
    </div>
    </>
    );
}
