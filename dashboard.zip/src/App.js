import React from "react";
import Reliancecompany from "pages/Reliancecompany";
// import Dashboard from "pages/Dashboard";
import Homepage from "pages/Homepage";
export default function App() {
  
  return (
    <div>
      {/* <Homepage/> */}
      <Reliancecompany/>
    </div>
  );
}