import React, { useState } from 'react';
import * as FaIcons from 'react-icons/fa';
import * as AiIcons from 'react-icons/ai';
import * as IoIcons from 'react-icons/io';
import { Link } from 'react-router-dom';
import './Vertical-Sidebar.css';
import { IconContext } from 'react-icons';

const SidebarData = [
  {
    title: 'Dashboard',
    path: '../pages/Dashboard.jsx',
    icon: <AiIcons.AiFillHome />,
    cName: 'nav-text'
  },
  {
    title: 'News',
    path: '../pages/Reliance.jsx',
    icon: <IoIcons.IoIosPaper />,
    cName: 'nav-text'
  },
  {
    title: 'Reliance',
    path: '/products',
    icon: <AiIcons.AiFillTrademarkCircle />,
    cName: 'nav-text'
  },
  {
    title: 'ITC',
    path: '/team',
    icon: <AiIcons.AiFillTrademarkCircle />,
    cName: 'nav-text'
  },
  {
    title: 'TCS',
    path: '/messages',
    icon: <AiIcons.AiFillTrademarkCircle />,
    cName: 'nav-text'
  },
  {
    title: 'HDFC',
    path: '/support',
    icon: <AiIcons.AiFillTrademarkCircle />,
    cName: 'nav-text'
  }
];

export default function VSIDEBAR() {
  const [sidebar, setSidebar] = useState(false);

  const showSidebar = () => setSidebar(!sidebar);

  return (
    <>
      <IconContext.Provider value={{ color: '#fff' }}>
        {/* <div className='navbar'>
          <Link to='#' className='menu-bars'>
            <FaIcons.FaBars onClick={showSidebar} />
          </Link>
        </div> */}
        <nav className={sidebar ? 'nav-menu active' : 'nav-menu'}>
          <ul className='nav-menu-items' onClick={showSidebar}>
            <li className='navbar-toggle'>
              {/* <Link to='#' className='menu-bars'>
                <AiIcons.AiOutlineClose />
              </Link> */}
            </li>
            {SidebarData.map((item, index) => {
              return (
                <li key={index} className={item.cName}>
                  <Link to={item.path}>
                    {item.icon}
                    <span>{item.title}</span>
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>
      </IconContext.Provider>
    </>
  );
}
