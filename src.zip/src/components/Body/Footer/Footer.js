import React from 'react';
import './Footer.css';
// import logoUrl from '../../assets/logo.svg';
export default function Footer(){
  return(
    <>
      <div className="footer">
          <h6>Created by Ramnath bhat</h6>
      </div>
    </>)
}