import React from "react"
import LNavbar from "./Link-Navbar/Link-Navbar.js"
import Footer from "./Footer/Footer.js"
import "./Body.css"
import Graph from "./Graph/Graph.js"
import CDetails from "./Company-Details/Company-Details.js"
export default function Body(){
    return(
    <>
    <div className="body-space">
        <LNavbar/>
        <Graph/>
        <CDetails/>
        <Footer/>
    </div> 
    </>)
}