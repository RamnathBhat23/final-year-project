import React from "react";
import "./Graph.css";
import Card from 'react-bootstrap/Card';
export default function Graph(){
    return(
        <>
       <Card className="text-center">
      <Card.Header className="graph-header"></Card.Header>
      <Card.Body className="graph-cd-main">
        <Card.Title></Card.Title>
        <Card.Text className="">
            <Card.Header className="graph-company-details-info">
                <Card.Text className="graph-company-title"> 
                <Card.Title>Company Name</Card.Title>
                    <div className="binline body-figures-left">
                    Open Digit
                    </div>
                    <div className="binline body-figures-right ">
                    Close Digit
                    </div>
                </Card.Text>
            </Card.Header>

        </Card.Text>
        <Card body>This is where graph will be displayed
        <br></br>
        <br></br>
        <br></br>
        <br></br>
        <br></br>
        <br></br>
        
        </Card>
        {/* <Button variant="primary">Go somewhere</Button> */}
      </Card.Body>
      <Card.Footer className="text-muted graph-footer"> </Card.Footer>
    </Card>
        </>
    )
}


