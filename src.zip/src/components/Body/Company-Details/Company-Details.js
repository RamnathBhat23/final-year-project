import React from "react";
import "./Company-Details.css";
import Card from 'react-bootstrap/Card';
import ListGroup from 'react-bootstrap/ListGroup';
export default function CDetails(){
    return(
        <>
        <div className="cdetails-container">
          <Card bg="secondary">
              <Card.Body>
                <div className="cdetails-struct">
                 {/* <Card.Body></Card.Body> */}
                 <Card bg="info" className="cdetails-tables">
                    <Card.Header>Company Details</Card.Header>
                      <ListGroup variant="flush">
                        <ListGroup.Item>display different company details</ListGroup.Item>
                        <ListGroup.Item>inform of entitity and its value</ListGroup.Item>
                        <ListGroup.Item>eg capital      2333</ListGroup.Item>
                        <ListGroup.Item>display different company details</ListGroup.Item>
                        <ListGroup.Item>inform of entitity and its value</ListGroup.Item>
                        <ListGroup.Item>eg capital      2333</ListGroup.Item>
                    </ListGroup>
                  </Card>
                 <Card bg="info" className="cdetails-tables">
                    <Card.Header>Company Details</Card.Header>
                      <ListGroup variant="flush">
                        <ListGroup.Item>display different company details</ListGroup.Item>
                        <ListGroup.Item>inform of entitity and its value</ListGroup.Item>
                        <ListGroup.Item>eg capital      2333</ListGroup.Item>
                        <ListGroup.Item>display different company details</ListGroup.Item>
                        <ListGroup.Item>inform of entitity and its value</ListGroup.Item>
                        <ListGroup.Item>eg capital      2333</ListGroup.Item>
                    </ListGroup>
                  </Card>
                 <Card bg="danger" className="cdetails-tables">
                    <Card.Header>Sentiment Score</Card.Header>
                    <ListGroup variant="flush">
                        <ListGroup.Item>Add your sentimnet meter here</ListGroup.Item>
                    </ListGroup>
                  </Card>
                  {/* <div className="cdetails-vline cdetails-tables"></div> */}
                </div>
              </Card.Body>
          </Card>
        </div>
        </>
    )
}