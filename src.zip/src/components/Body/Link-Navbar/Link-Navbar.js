import React from "react"
import "./Link-Navbar.css"
export default function LNavbar(){
    return(
    <>       
     <div className="navbar-div">
        <hr className="navbar-hr"></hr>
        <ul className="navbar-items-grp">
            <a classname="navbar-items" href="google.com"><p className="navbar-content">Market Sentiments<p/></p></a>
            <a classname="navbar-items" href="google.com"><p  className="navbar-content">Companies<p/></p></a>
            <a  classname="navbar-items" href="google.com"><p  className="navbar-content">News & Analysis<p/></p></a>
        </ul>
        {/* <hr className="navbar-hr"></hr> */}
     </div>
    </>)
}