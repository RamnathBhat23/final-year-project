import React from "react";
import "./Graph.css";

export default function(){
    return(
        <>
        </>
    )
}