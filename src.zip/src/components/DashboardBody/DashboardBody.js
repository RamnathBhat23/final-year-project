import React from "react";
import DashboardHead from "./DashboardHead/DashboardHead";
import "./DashboardBody.css";
// import DASHCOMPANY from "./DashBoardCompanies/DashboardCompanies";
export default function DASHBODY(){
    return(
    <>
    <div className="body-space">
        <DashboardHead/>
        {/* <DASHCOMPANY/> */}
    </div> 
    </>)
}