import React from "react";
import "./DashboardHead.css"
import Image from 'react-bootstrap/Image'
import Card from 'react-bootstrap/Card';

export default function DashboardHead(){
    return(
    <>
      <Card className="bg-dark text-white left-spacing">
      {/* <Card.Img className="" alt="Card image"/> */}
      <div className="img-property">
        {/* <h1>fjksdfdsajkl</h1> */}
        <img src="https://i.pinimg.com/originals/bb/60/17/bb6017228045fe34e13fc9023eb4e2d7.jpg" className="img-overlay"></img>
      </div>
      {/* <Card.ImgOverlay>
        <Card.Title>Trading is Evolving</Card.Title>
        <Card.Text>
          But machines are making better decisions
        </Card.Text>
        <Card.Text>Last updated 3 mins ago</Card.Text>
      </Card.ImgOverlay> */}
    </Card>
    </>)
}