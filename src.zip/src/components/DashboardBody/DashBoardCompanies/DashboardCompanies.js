import React from "react";
import "./DashboardCompanies.css";

export default function DASHCOMPANY(){
    return(
        <>
        <h1 className="dashcompanies-body">wjffffffffffffffffffffdfjfja</h1>
        </>
    );
}