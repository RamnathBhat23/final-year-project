import React from 'react'

export default function DailyStats() {
  return (
    <div className='daily-stats-container gradient-border'>
        <div className='metric-container'>
            <span className='metric-title'>Stock price</span>
            <span className='metric-value'>Rs 2500</span>
        </div>
        <div className='metric-container'>
            <span className='metric-title'>Total volume</span>
            <span className='metric-value'>250000</span>
        </div>
        <div className='metric-container'>
            <span className='metric-title'>Companies pridicted</span>
            <span className='metric-value'>4 Companies</span>
        </div>
        <div className='metric-container'>
            <span className='metric-title'>Accuracy</span>
            <span className='metric-value'>00:00%</span>
        </div>
    </div>


  )
}

