import React from "react";
// import search from '../../assets/icons/search.png';
// import { ReactComponent as TelegramIcon } from "../assets/icons/telegram.svg";
import hero from "../../assets/icons/stock.webp";

export default function HeroSection(){
    return(<>
    <div className="hero-section-container">
        <div className="hero-info-wrapper">
            <div className="hero-info-text">

            <h1>
                 The <span className="highlighted">Best stock prediction</span>
            </h1>
            <p className="hero-info-description">
                Trading is evolving , also machine are imporving prediction.
            </p>
            {/* <div className="search-container">
                <div className="search-input-wrapper">
                    <img className="search" src={search} alt="search"/>
                    <input className="search-input" placeholder="Search for stocks"></input>
                </div>
                <button className="search-btn primary">
                    <span className="start-swapping">
                        Start Swaping
                    </span>
                </button>
            </div> */}
                <div className="social-links-container">
                    <div className="social-links">
                        <a href="/">
                            {/* <TelegramIcon/> */}
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div className="hero-image-container">
            <div>
                <img className="hero-img" src={hero} alt="stockmarket"/>
            </div>
        </div>
    </div>
    </>
    );
}
