import "./App.css";
// import SideBar from "./components/Sidebar/SideBar";
import React from "react"
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Dashboard from "./pages/Dashboard.jsx";
// import  from "./pages/";
// import  from "./pages/";
// import  from "./pages/";
// import  from "./pages/";
// import  from "./pages/";
// import  from "./pages/";
// import  from "./pages/";
function App() {
  return (
    <Router>
      <Dashboard/>
      {/* <SideBar> */}
        <Routes>
          {/* <Route path="/dashboard" element={<Dashboard />} /> */}
          {/* <Route path="/" element={< />} />
          <Route path="/" element={< />} />
          <Route path="/" element={< />} />
          <Route path="/" element={< />} />
          <Route path="/" element={< />} />
          <Route path="/" element={< />} />
          <Route path="/" element={< />} /> */}

          {/* <Route path="*" element={<> not found</>} /> */}
        </Routes>
      {/* </SideBar> */}
    </Router>
  );
}

export default App;