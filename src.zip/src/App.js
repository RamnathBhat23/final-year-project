import "./App.css";
// import SideBar from "./components/Sidebar/SideBar";
import React from "react"
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
// import Dashboard from "./pages/Dashboard.jsx";
import Reliance from "./pages/Reliance";
import TCS from "./pages/TCS";
import Homepage from "./pages/Homepage";
function App() {
  return (
      <Router>
        <Routes>
          <Route path="/" element={<Homepage />} />
          <Route path="Reliance" element={<Reliance/>} />
          <Route path="TCS" element={<TCS/>} />
          <Route path="*" element={<> not found</>} /> 
        </Routes>
      </Router>
   
  );
}

export default App;