import React from 'react'
// import '../App.css';
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import '../components/Homepage/Homepage.css';

import Header from '../components/Homepage/Header'
import HeroSection from '../components/Homepage/HeroSection'
import FeatureOne  from '../components/Homepage/FeatureOne';
import DailyStats from '../components/Homepage/DailyStats';
import { Card } from '../components/Homepage/Card';
import Price from '../assets/icons/search.png';
import Footer from '../components/Homepage/Footer';
import Research from '../assets/icons/Research.svg';
import Performance from '../assets/icons/Performance.svg';



export default function Homepage() {
    const features=[{
        src: Research,
        title:"Good Reasearch",
        description:"Show you better opening and closing price as better research is done"
      },
      {
        src: Performance,
        title:"High Performance",
        description:"Show you better opening and closing price with good surceptibility"
      },
      {
        src: Price,
        title:"Better price",
        description:"Show you better opening and closing price"
      },
      {
        src: Price,
        title:"Better price",
        description:"Show you better opening and closing price"
      }
      ]
    return (
      <>
    <div className="home">
     <Header/>
     <HeroSection/>
     <DailyStats/>
     <FeatureOne/>
     <div className='features-list-container'>
      {
        features.map((feature,index)=>{
          return(
          <Card key={index} title={feature.title} imgUrl={feature.src}> {
          <p>{feature.description}</p>}</Card>
          )
        })
      }
     </div>
     <Footer/>
    </div>
   </>
  );
}
