import Header from '../components/Header/Header';
import VSIDEBAR from '../components/Vertical-Sidebar/Vertical-Sidebar';
import Body from '../components/Body/Body'
export default function Reliance(){
    return (
        <>
        <Header/>
        <VSIDEBAR/>
        <Body/>
        </>
    )
}